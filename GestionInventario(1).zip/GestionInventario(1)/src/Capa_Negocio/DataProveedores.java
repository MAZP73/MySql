package Capa_Negocio;

import java.util.ArrayList;
import java.sql.*;
import Capa_Datos.Conexion;

public class DataProveedores {

    private int id_proveedor;
    private String nombre_proveedor;
    private String apellido_proveedor;
    private String telefono;
    private String email;

    // Método para eliminar un proveedor
    public String EliminarProveedor() {
        Conexion objmod = new Conexion();
        String cad = "DELETE FROM proveedores WHERE id_proveedor = " + this.getId_proveedor();
        return objmod.Ejecutar(cad);
    }

    // Método para grabar un nuevo proveedor (modificado para incluir id_proveedor)
    public String GrabarProveedor() {
        Conexion objmod = new Conexion();
        String cad = "INSERT INTO proveedores (id_proveedor, nombre_proveedor, apellido_proveedor, telefono, email) "
                + "VALUES (" + this.getId_proveedor() + ", '" + this.getNombre_proveedor() + "', '" + this.getApellido_proveedor() 
                + "', '" + this.getTelefono() + "', '" + this.getEmail() + "')";
        return objmod.Ejecutar(cad);
    }

    // Método para editar un proveedor existente
    public String EditarProveedor() {
        Conexion objmod = new Conexion();
        String cad = "UPDATE proveedores SET nombre_proveedor = '" + this.getNombre_proveedor() 
                + "', apellido_proveedor = '" + this.getApellido_proveedor() 
                + "', telefono = '" + this.getTelefono() 
                + "', email = '" + this.getEmail() 
                + "' WHERE id_proveedor = " + this.getId_proveedor();
        return objmod.Ejecutar(cad);
    }

    // Método para listar todos los proveedores
    public ArrayList<DataProveedores> ListaProveedores() {
        ArrayList<DataProveedores> listaProveedores = new ArrayList<>();
        try {
            Conexion objmod = new Conexion();
            ResultSet tabla = objmod.Listar("SELECT * FROM proveedores");
            DataProveedores objProv;
            while (tabla.next()) {
                objProv = new DataProveedores();
                objProv.setId_proveedor(tabla.getInt("id_proveedor"));
                objProv.setNombre_proveedor(tabla.getString("nombre_proveedor"));
                objProv.setApellido_proveedor(tabla.getString("apellido_proveedor"));
                objProv.setTelefono(tabla.getString("telefono"));
                objProv.setEmail(tabla.getString("email"));
                listaProveedores.add(objProv);
            }
        } catch (SQLException e) {
            javax.swing.JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return listaProveedores;
    }

    // Métodos getter y setter
    public int getId_proveedor() {
        return id_proveedor;
    }

    public void setId_proveedor(int id_proveedor) {
        this.id_proveedor = id_proveedor;
    }

    public String getNombre_proveedor() {
        return nombre_proveedor;
    }

    public void setNombre_proveedor(String nombre_proveedor) {
        this.nombre_proveedor = nombre_proveedor;
    }

    public String getApellido_proveedor() {
        return apellido_proveedor;
    }

    public void setApellido_proveedor(String apellido_proveedor) {
        this.apellido_proveedor = apellido_proveedor;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
