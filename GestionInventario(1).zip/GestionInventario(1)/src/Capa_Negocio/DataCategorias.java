package Capa_Negocio;

import Capa_Datos.Conexion;
import java.sql.*;
import java.util.ArrayList;

public class DataCategorias {

    private int id_categoria;
    private String nombre_categoria;

    // Constructor
    public DataCategorias() {
    }

    // Constructor con parámetros
    public DataCategorias(int id_categoria, String nombre_categoria) {
        this.id_categoria = id_categoria;
        this.nombre_categoria = nombre_categoria;
    }

    // Métodos getter y setter
    public int getId_categoria() {
        return id_categoria;
    }

    public void setId_categoria(int id_categoria) {
        this.id_categoria = id_categoria;
    }

    public String getNombre_categoria() {
        return nombre_categoria;
    }

    public void setNombre_categoria(String nombre_categoria) {
        this.nombre_categoria = nombre_categoria;
    }

    // Método para agregar una nueva categoría
    public String agregarCategoria() {
        Conexion objmod = new Conexion();
        String query = "INSERT INTO Categorias (nombre_categoria) VALUES ('" + this.getNombre_categoria() + "')";
        return objmod.Ejecutar(query);  // Ejecuta la consulta de inserción
    }

    // Método para modificar una categoría existente
    public String modificarCategoria() {
        Conexion objmod = new Conexion();
        String query = "UPDATE Categorias SET nombre_categoria = '" + this.getNombre_categoria() + "' WHERE id_categoria = " + this.getId_categoria();
        return objmod.Ejecutar(query);  // Ejecuta la consulta de actualización
    }

    // Método para eliminar una categoría
    public String eliminarCategoria() {
        Conexion objmod = new Conexion();
        String query = "DELETE FROM Categorias WHERE id_categoria = " + this.getId_categoria();
        return objmod.Ejecutar(query);  // Ejecuta la consulta de eliminación
    }

    // Método para listar todas las categorías
    public ArrayList<DataCategorias> listarCategorias() {
        ArrayList<DataCategorias> listaCategorias = new ArrayList<>();
        Conexion objmod = new Conexion();
        String query = "SELECT * FROM Categorias";  // Consulta para seleccionar todas las categorías
        try {
            ResultSet rs = objmod.Listar(query);
            while (rs.next()) {
                DataCategorias categoria = new DataCategorias();
                categoria.setId_categoria(rs.getInt("id_categoria"));
                categoria.setNombre_categoria(rs.getString("nombre_categoria"));
                listaCategorias.add(categoria);  // Añade la categoría a la lista
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listaCategorias;  // Devuelve la lista de categorías
    }

    @Override
    public String toString() {
        return "Categoría: " + nombre_categoria;
    }
}
