package Capa_Negocio;

import java.util.ArrayList;
import java.sql.*;
import Capa_Datos.Conexion;

public class DataProducto {

    private String id_producto;  // Cambiado a String para coincidir con VARCHAR(100) en SQL
    private String nombre_producto;
    private double precio;
    private int stock;
    private int id_categoria;
    private int id_proveedor;

    // Método para eliminar un producto
    public String EliminarProducto() {
        Conexion objmod = new Conexion();
        String cad = "DELETE FROM productos WHERE id_producto = '" + this.getId_producto() + "'";  // Asegurarse de que id_producto es un String
        return objmod.Ejecutar(cad);
    }

    // Método para grabar un nuevo producto
    public String GrabarProducto() {
        Conexion objmod = new Conexion();
        String cad = "INSERT INTO productos (id_producto, nombre_producto, precio, stock, id_categoria, id_proveedor) "
                + "VALUES ('" + this.getId_producto() + "', '" + this.getNombre_producto() + "', "
                + this.getPrecio() + ", " + this.getStock() + ", " + this.getId_categoria() + ", " + this.getId_proveedor() + ")";
        return objmod.Ejecutar(cad);
    }

    // Método para editar un producto existente
    public String EditarProducto() {
        Conexion objmod = new Conexion();
        String cad = "UPDATE productos SET nombre_producto = '" + this.getNombre_producto() 
                + "', precio = " + this.getPrecio() 
                + ", stock = " + this.getStock() 
                + ", id_categoria = " + this.getId_categoria() 
                + ", id_proveedor = " + this.getId_proveedor() 
                + " WHERE id_producto = '" + this.getId_producto() + "'";  // id_producto como String
        return objmod.Ejecutar(cad);
    }

    // Método para listar todos los productos
    public ArrayList<DataProducto> ListaProductos() {
        ArrayList<DataProducto> listaProductos = new ArrayList<>();
        try {
            Conexion objmod = new Conexion();
            ResultSet tabla = objmod.Listar("SELECT * FROM productos");
            DataProducto objProd;
            while (tabla.next()) {
                objProd = new DataProducto();
                objProd.setId_producto(tabla.getString("id_producto"));  // Cambiado a String
                objProd.setNombre_producto(tabla.getString("nombre_producto"));
                objProd.setPrecio(tabla.getDouble("precio"));
                objProd.setStock(tabla.getInt("stock"));
                objProd.setId_categoria(tabla.getInt("id_categoria"));
                objProd.setId_proveedor(tabla.getInt("id_proveedor"));
                listaProductos.add(objProd);
            }
        } catch (SQLException e) {
            javax.swing.JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return listaProductos;
    }

    // Métodos getter y setter
    public String getId_producto() {
        return id_producto;
    }

    public void setId_producto(String id_producto) {
        this.id_producto = id_producto;
    }

    public String getNombre_producto() {
        return nombre_producto;
    }

    public void setNombre_producto(String nombre_producto) {
        this.nombre_producto = nombre_producto;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public int getId_categoria() {
        return id_categoria;
    }

    public void setId_categoria(int id_categoria) {
        this.id_categoria = id_categoria;
    }

    public int getId_proveedor() {
        return id_proveedor;
    }

    public void setId_proveedor(int id_proveedor) {
        this.id_proveedor = id_proveedor;
    }
}
