package Capa_Negocio;

import java.util.ArrayList;
import java.sql.*;
import Capa_Datos.Conexion;

public class DataMovimiento {

    private int id_movimiento;
    private String id_producto;
    private String tipo_movimiento;
    private int cantidad;
    private Timestamp fecha;

    public ArrayList<DataMovimiento> ListaMovimientos() {
        ArrayList<DataMovimiento> listaMovimientos = new ArrayList<>();
        try {
            Conexion objmod = new Conexion();
            String consulta = "SELECT m.id_movimiento, m.id_producto, p.nombre_producto, "
                    + "m.tipo_movimiento, m.cantidad, m.fecha "
                    + "FROM MovimientosInventario m "
                    + "JOIN Productos p ON m.id_producto = p.id_producto";
            ResultSet tabla = objmod.Listar(consulta);

            while (tabla.next()) {
                System.out.println("Movimiento encontrado: " + tabla.getInt("id_movimiento"));
                DataMovimiento objMov = new DataMovimiento();
                objMov.setId_movimiento(tabla.getInt("id_movimiento"));
                objMov.setId_producto(tabla.getString("id_producto") + " - " + tabla.getString("nombre_producto"));
                objMov.setTipo_movimiento(tabla.getString("tipo_movimiento"));
                objMov.setCantidad(tabla.getInt("cantidad"));
                objMov.setFecha(tabla.getTimestamp("fecha"));
                listaMovimientos.add(objMov);
            }
        } catch (SQLException e) {
            javax.swing.JOptionPane.showMessageDialog(null, "Error al listar movimientos: " + e.getMessage());
        }
        return listaMovimientos;
    }

    // Métodos getter y setter
    public int getId_movimiento() {
        return id_movimiento;
    }

    public void setId_movimiento(int id_movimiento) {
        this.id_movimiento = id_movimiento;
    }

    public String getId_producto() {
        return id_producto;
    }

    public void setId_producto(String id_producto) {
        this.id_producto = id_producto;
    }

    public String getTipo_movimiento() {
        return tipo_movimiento;
    }

    public void setTipo_movimiento(String tipo_movimiento) {
        this.tipo_movimiento = tipo_movimiento;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public Timestamp getFecha() {
        return fecha;
    }

    public void setFecha(Timestamp fecha) {
        this.fecha = fecha;
    }
}
