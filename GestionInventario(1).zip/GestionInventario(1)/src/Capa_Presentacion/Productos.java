package Capa_Presentacion;

import Capa_Datos.Conexion;
import Capa_Negocio.DataProducto;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class Productos extends javax.swing.JInternalFrame {

    /**
     * Creates new form Productos
     */
    public Productos() {
        initComponents();
        ListarProductos();
        PoblarComboBoxProveedor();
        PoblarComboBoxCategoria();
        bt_grabar.setEnabled(false);
    }

    public void ListarProductos() {
        DefaultTableModel tabla = new DefaultTableModel();
        DataProducto objprod = new DataProducto();
        ArrayList<DataProducto> listaProductos = objprod.ListaProductos();

        // Añadir columnas a la tabla
        tabla.addColumn("ID Producto");
        tabla.addColumn("Nombre Producto");
        tabla.addColumn("Precio");
        tabla.addColumn("Stock");
        tabla.addColumn("Categoría");
        tabla.addColumn("Proveedor");

        // Configurar las filas de la tabla según la lista de productos
        tabla.setRowCount(listaProductos.size());

        int i = 0;
        for (DataProducto p : listaProductos) {
            tabla.setValueAt(p.getId_producto(), i, 0);
            tabla.setValueAt(p.getNombre_producto(), i, 1);
            tabla.setValueAt(p.getPrecio(), i, 2);
            tabla.setValueAt(p.getStock(), i, 3);
            tabla.setValueAt(p.getId_categoria(), i, 4);
            tabla.setValueAt(p.getId_proveedor(), i, 5);
            i++;
        }

        this.jTable1.setModel(tabla);
    }

    public void LimpiarCajasTexto() {
        this.tx_Codigo.setText("");
        this.tx_Nombre.setText("");
        this.tx_Precio.setText("");
        this.tx_Stock.setText("");
        // Limpiar los ComboBox solo si tienen elementos
        if (com_categoria.getItemCount() > 0) {
            com_categoria.setSelectedIndex(0);  // Establecer el primer item si existen elementos
        }

        if (com_proveedor.getItemCount() > 0) {
            com_proveedor.setSelectedIndex(0);  // Establecer el primer item si existen elementos
        }
    }

    public void PoblarComboBoxCategoria() {
        try {
            Conexion objmod = new Conexion();
            ResultSet rs = objmod.Listar("SELECT id_categoria, nombre_categoria FROM categorias");
            boolean datosCargados = false; // Para verificar si hay datos
            while (rs.next()) {
                this.com_categoria.addItem(rs.getString("id_categoria") + " - " + rs.getString("nombre_categoria"));
                datosCargados = true;
            }
            if (!datosCargados) {
                JOptionPane.showMessageDialog(null, "No se encontraron categorías en la base de datos.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar las categorías: " + e.getMessage());
        }
    }

    public void PoblarComboBoxProveedor() {
        try {
            Conexion objmod = new Conexion();
            ResultSet rs = objmod.Listar("SELECT id_proveedor, nombre_proveedor FROM proveedores");
            boolean datosCargados = false; // Para verificar si hay datos
            while (rs.next()) {
                this.com_proveedor.addItem(rs.getString("id_proveedor") + " - " + rs.getString("nombre_proveedor"));
                datosCargados = true;
            }
            if (!datosCargados) {
                JOptionPane.showMessageDialog(null, "No se encontraron proveedores en la base de datos.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los proveedores: " + e.getMessage());
        }
    }

    private boolean validarCampos() {
        if (tx_Codigo.getText().isEmpty() || tx_Nombre.getText().isEmpty()
                || tx_Precio.getText().isEmpty() || tx_Stock.getText().isEmpty()) {
            lbvalidacion.setText("Por favor, complete todos los campos.");
            return false;
        }

        if (!tx_Codigo.getText().matches("\\w+")) {
            lbvalidacion.setText("El campo Código no debe contener caracteres especiales.");
            return false;
        }

        if (!tx_Nombre.getText().matches("[a-zA-Z ]+")) {
            lbvalidacion.setText("El campo Nombre solo debe contener letras.");
            return false;
        }

        if (!tx_Precio.getText().matches("\\d+(\\.\\d+)?")) {
            lbvalidacion.setText("El campo Precio solo debe contener números.");
            return false;
        }

        if (!tx_Stock.getText().matches("\\d+")) {
            lbvalidacion.setText("El campo Stock solo debe contener números enteros.");
            return false;
        }

        lbvalidacion.setText(""); // Limpiar mensajes si todo es válido
        return true;
    }

    private void registrarMovimientoInventario(String idProducto, String tipoMovimiento) {
        // Obtener el stock actual del producto desde la base de datos
        int stock = obtenerStockProducto(idProducto);

        // Consulta SQL para insertar el movimiento en la tabla MovimientosInventario
        String sql = "INSERT INTO MovimientosInventario (id_producto, tipo_movimiento, cantidad) VALUES (?, ?, ?)";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ss_gestion_inventario?useSSL=false", "root", "1234"); PreparedStatement pst = conn.prepareStatement(sql)) {

            // Establecer los parámetros de la consulta
            pst.setString(1, idProducto);        // id_producto
            pst.setString(2, tipoMovimiento);    // tipo_movimiento ('Entrada' o 'Salida')
            pst.setInt(3, stock);                // cantidad es igual al stock actual

            // Ejecutar la consulta
            pst.executeUpdate();

            // Si la inserción es exitosa, mostrar mensaje de éxito
            System.out.println("Movimiento de inventario registrado correctamente.");

        } catch (SQLException e) {
            // Si ocurre un error, mostrar el mensaje de error
            JOptionPane.showMessageDialog(null, "Error al registrar movimiento de inventario: " + e.getMessage());
        }
    }

    private int obtenerStockProducto(String idProducto) {
        int stock = 0;
        String sql = "SELECT stock FROM Productos WHERE id_producto = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ss_gestion_inventario?useSSL=false", "root", "1234"); PreparedStatement pst = conn.prepareStatement(sql)) {

            // Establecer el parámetro para la consulta
            pst.setString(1, idProducto);

            // Ejecutar la consulta y obtener el resultado
            ResultSet rs = pst.executeQuery();

            // Si se encuentra el producto, obtener el stock
            if (rs.next()) {
                stock = rs.getInt("stock");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener el stock del producto: " + e.getMessage());
        }

        return stock;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        tx_Codigo = new javax.swing.JTextField();
        tx_Nombre = new javax.swing.JTextField();
        tx_Precio = new javax.swing.JTextField();
        tx_Stock = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        bt_nuevo = new javax.swing.JButton();
        bt_modificar = new javax.swing.JButton();
        bt_eliminar = new javax.swing.JButton();
        bt_grabar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        lbvalidacion = new javax.swing.JLabel();
        com_categoria = new javax.swing.JComboBox<>();
        com_proveedor = new javax.swing.JComboBox<>();

        setClosable(true);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jTable1MousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        tx_Codigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tx_CodigoActionPerformed(evt);
            }
        });

        tx_Stock.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tx_StockActionPerformed(evt);
            }
        });

        jLabel1.setText("Codigo:");

        jLabel2.setText("Nombre:");

        jLabel4.setText("Precio:");

        jLabel5.setText("Stock:");

        jLabel6.setText("Categoria:");

        bt_nuevo.setText("Nuevo");
        bt_nuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_nuevoActionPerformed(evt);
            }
        });

        bt_modificar.setText("Modificar");
        bt_modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_modificarActionPerformed(evt);
            }
        });

        bt_eliminar.setText("Eliminar");
        bt_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_eliminarActionPerformed(evt);
            }
        });

        bt_grabar.setText("Grabar");
        bt_grabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_grabarActionPerformed(evt);
            }
        });

        jLabel7.setText("Proveedor:");

        lbvalidacion.setText(".");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(59, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbvalidacion)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(tx_Codigo)
                            .addComponent(tx_Nombre)
                            .addComponent(tx_Precio)
                            .addComponent(tx_Stock, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                            .addComponent(com_categoria, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(com_proveedor, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 557, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(bt_nuevo)
                        .addGap(18, 18, 18)
                        .addComponent(bt_grabar)
                        .addGap(18, 18, 18)
                        .addComponent(bt_modificar)
                        .addGap(18, 18, 18)
                        .addComponent(bt_eliminar)))
                .addGap(17, 17, 17))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tx_Codigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tx_Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tx_Precio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tx_Stock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(com_categoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(com_proveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt_nuevo)
                    .addComponent(bt_modificar)
                    .addComponent(bt_grabar)
                    .addComponent(bt_eliminar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbvalidacion)
                .addContainerGap(59, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tx_CodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tx_CodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tx_CodigoActionPerformed

    private void tx_StockActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tx_StockActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tx_StockActionPerformed

    private void bt_nuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_nuevoActionPerformed
        LimpiarCajasTexto();
        bt_grabar.setEnabled(true);
    }//GEN-LAST:event_bt_nuevoActionPerformed

    private void bt_grabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_grabarActionPerformed
        if (!validarCampos()) {
            return;
        }

        DataProducto objprod = new DataProducto();

        objprod.setId_producto(this.tx_Codigo.getText());
        objprod.setNombre_producto(this.tx_Nombre.getText());
        objprod.setPrecio(Double.parseDouble(this.tx_Precio.getText()));
        objprod.setStock(Integer.parseInt(this.tx_Stock.getText()));

        // Obtener categoría y proveedor seleccionados
        String categoriaSeleccionada = this.com_categoria.getSelectedItem().toString().split(" - ")[0];
        String proveedorSeleccionado = this.com_proveedor.getSelectedItem().toString().split(" - ")[0];

        objprod.setId_categoria(Integer.parseInt(categoriaSeleccionada));
        objprod.setId_proveedor(Integer.parseInt(proveedorSeleccionado));


        JOptionPane.showMessageDialog(null, objprod.GrabarProducto());
        LimpiarCajasTexto();
        ListarProductos();
    }//GEN-LAST:event_bt_grabarActionPerformed

    private void bt_modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_modificarActionPerformed

        if (!validarCampos()) {
            return;
        }

        // Verificar si el campo Código fue modificado
        int rec = this.jTable1.getSelectedRow(); // Obtener la fila seleccionada
        if (rec == -1) {
            JOptionPane.showMessageDialog(null, "Por favor, seleccione un producto para modificar.");
            return;
        }

        String codigoOriginal = jTable1.getValueAt(rec, 0).toString(); // Código original de la tabla
        if (!tx_Codigo.getText().equals(codigoOriginal)) {
            JOptionPane.showMessageDialog(null, "El código no se puede modificar.");
            tx_Codigo.setText(codigoOriginal); // Restaurar el código original
            return;
        }

        // Si el código no fue modificado, continuar con la edición
        DataProducto objprod = new DataProducto();

        objprod.setId_producto(codigoOriginal);
        objprod.setNombre_producto(this.tx_Nombre.getText());
        objprod.setPrecio(Double.parseDouble(this.tx_Precio.getText()));
        objprod.setStock(Integer.parseInt(this.tx_Stock.getText()));

        // Obtener categoría y proveedor seleccionados
        String categoriaSeleccionada = this.com_categoria.getSelectedItem().toString().split(" - ")[0];
        String proveedorSeleccionado = this.com_proveedor.getSelectedItem().toString().split(" - ")[0];

        objprod.setId_categoria(Integer.parseInt(categoriaSeleccionada));
        objprod.setId_proveedor(Integer.parseInt(proveedorSeleccionado));

        // Llamada al método registrarMovimientoInventario después de modificar el producto
        registrarMovimientoInventario(objprod.getId_producto(), "Entrada");

        JOptionPane.showMessageDialog(null, objprod.EditarProducto());
        LimpiarCajasTexto();
        ListarProductos();

    }//GEN-LAST:event_bt_modificarActionPerformed

    private void bt_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_eliminarActionPerformed

        String codigoEliminar = tx_Codigo.getText(); // Obtener el código ingresado en el campo de texto

        // Verificar si hay un código ingresado
        if (codigoEliminar.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, ingrese el código del producto a eliminar.");
            return;
        }

        // Verificar si el código existe en la tabla
        boolean codigoExiste = false;
        for (int i = 0; i < jTable1.getRowCount(); i++) {
            String codigoTabla = jTable1.getValueAt(i, 0).toString();
            if (codigoTabla.equals(codigoEliminar)) {
                codigoExiste = true;
                break;
            }
        }

        // Si no existe, mostrar mensaje y salir
        if (!codigoExiste) {
            JOptionPane.showMessageDialog(null, "El producto con el código '" + codigoEliminar + "' no existe y no se puede eliminar.");
            return;
        }

        // Si existe, proceder con la eliminación
        DataProducto objprod = new DataProducto();
        objprod.setId_producto(codigoEliminar);
        // Llamada al método registrarMovimientoInventario después de eliminar el producto
        registrarMovimientoInventario(objprod.getId_producto(), "Salida");

        JOptionPane.showMessageDialog(null, objprod.EliminarProducto());
        LimpiarCajasTexto();
        ListarProductos();
    }//GEN-LAST:event_bt_eliminarActionPerformed

    private void jTable1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MousePressed

        int rec = this.jTable1.getSelectedRow();  // Obtener la fila seleccionada en la tabla

        // Verificar si se ha seleccionado alguna fila
        if (rec != -1) {
            // Asignar los valores de la fila seleccionada a los campos de texto correspondientes
            this.tx_Codigo.setText(jTable1.getValueAt(rec, 0).toString());
            this.tx_Nombre.setText(jTable1.getValueAt(rec, 1).toString());
            this.tx_Precio.setText(jTable1.getValueAt(rec, 2).toString());
            this.tx_Stock.setText(jTable1.getValueAt(rec, 3).toString());

            // Asignar la categoría y proveedor seleccionados en los JComboBox
            // Obtener el ID de categoría y proveedor (deben coincidir con los valores en los ComboBox)
            String categoriaId = jTable1.getValueAt(rec, 4).toString(); // ID de categoría
            String proveedorId = jTable1.getValueAt(rec, 5).toString(); // ID de proveedor

            // Establecer el índice correspondiente en los ComboBox de categoría y proveedor
            for (int i = 0; i < com_categoria.getItemCount(); i++) {
                if (com_categoria.getItemAt(i).toString().split(" - ")[0].equals(categoriaId)) {
                    com_categoria.setSelectedIndex(i);
                    break;
                }
            }

            for (int i = 0; i < com_proveedor.getItemCount(); i++) {
                if (com_proveedor.getItemAt(i).toString().split(" - ")[0].equals(proveedorId)) {
                    com_proveedor.setSelectedIndex(i);
                    break;
                }
            }
        }

    }//GEN-LAST:event_jTable1MousePressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_eliminar;
    private javax.swing.JButton bt_grabar;
    private javax.swing.JButton bt_modificar;
    private javax.swing.JButton bt_nuevo;
    private javax.swing.JComboBox<String> com_categoria;
    private javax.swing.JComboBox<String> com_proveedor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lbvalidacion;
    private javax.swing.JTextField tx_Codigo;
    private javax.swing.JTextField tx_Nombre;
    private javax.swing.JTextField tx_Precio;
    private javax.swing.JTextField tx_Stock;
    // End of variables declaration//GEN-END:variables
}
