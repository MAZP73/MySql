package Capa_Presentacion;

import Capa_Datos.Conexion;
import Capa_Negocio.DataProveedores;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.HashSet;
import java.util.Set;

public class Proveedores extends javax.swing.JInternalFrame {

    /**
     * Creates new form Productos
     */
    public Proveedores() {
        initComponents();
        ListarProveedores();
        bt_grabar.setEnabled(false);
    }

    public void ListarProveedores() {
        DefaultTableModel tabla = new DefaultTableModel();
        DataProveedores objProv = new DataProveedores();
        ArrayList<DataProveedores> listaProveedores = objProv.ListaProveedores();

        // Añadiendo las columnas
        tabla.addColumn("ID Proveedor");
        tabla.addColumn("Nombre");
        tabla.addColumn("Apellido");
        tabla.addColumn("Teléfono");
        tabla.addColumn("Email");

        // Configurar el número de filas en la tabla según el tamaño de la lista
        tabla.setRowCount(listaProveedores.size());

        int i = 0;
        for (DataProveedores prov : listaProveedores) {
            tabla.setValueAt(prov.getId_proveedor(), i, 0);
            tabla.setValueAt(prov.getNombre_proveedor(), i, 1);
            tabla.setValueAt(prov.getApellido_proveedor(), i, 2);
            tabla.setValueAt(prov.getTelefono(), i, 3);
            tabla.setValueAt(prov.getEmail(), i, 4);
            i++;
        }

        this.jTable1.setModel(tabla);
    }

    public void LimpiarCajasTextoProveedor() {
        this.tx_id.setText("");
        this.tx_nombre.setText("");
        this.tx_apellido.setText("");
        this.tx_telefono.setText("");
        this.tx_email.setText("");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        tx_nombre = new javax.swing.JTextField();
        tx_apellido = new javax.swing.JTextField();
        tx_telefono = new javax.swing.JTextField();
        tx_email = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        bt_nuevo = new javax.swing.JButton();
        bt_modificar = new javax.swing.JButton();
        bt_eliminar = new javax.swing.JButton();
        bt_grabar = new javax.swing.JButton();
        lbvalidacion = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        tx_id = new javax.swing.JTextField();

        setClosable(true);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jTable1MousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        tx_nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tx_nombreActionPerformed(evt);
            }
        });

        tx_email.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tx_emailActionPerformed(evt);
            }
        });

        jLabel1.setText("Nombre:");

        jLabel2.setText("Apellido:");

        jLabel4.setText("Telefono:");

        jLabel5.setText("Email:");

        bt_nuevo.setText("Nuevo");
        bt_nuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_nuevoActionPerformed(evt);
            }
        });

        bt_modificar.setText("Modificar");
        bt_modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_modificarActionPerformed(evt);
            }
        });

        bt_eliminar.setText("Eliminar");
        bt_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_eliminarActionPerformed(evt);
            }
        });

        bt_grabar.setText("Grabar");
        bt_grabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_grabarActionPerformed(evt);
            }
        });

        lbvalidacion.setText(".");

        jLabel3.setText("ID:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(58, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbvalidacion)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tx_nombre, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)
                            .addComponent(tx_apellido, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(tx_telefono, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(tx_email)
                            .addComponent(tx_id))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 557, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(bt_nuevo)
                        .addGap(18, 18, 18)
                        .addComponent(bt_grabar)
                        .addGap(18, 18, 18)
                        .addComponent(bt_modificar)
                        .addGap(18, 18, 18)
                        .addComponent(bt_eliminar)))
                .addGap(17, 17, 17))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tx_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tx_apellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tx_telefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(tx_email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(tx_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt_nuevo)
                    .addComponent(bt_modificar)
                    .addComponent(bt_grabar)
                    .addComponent(bt_eliminar))
                .addGap(18, 18, 18)
                .addComponent(lbvalidacion)
                .addContainerGap(53, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tx_nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tx_nombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tx_nombreActionPerformed

    private void tx_emailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tx_emailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tx_emailActionPerformed

    private void bt_nuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_nuevoActionPerformed
        LimpiarCajasTextoProveedor();
        bt_grabar.setEnabled(true);
    }//GEN-LAST:event_bt_nuevoActionPerformed

    private void bt_grabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_grabarActionPerformed
        DataProveedores objProv = new DataProveedores();

        // Validaciones de los campos
        if (this.tx_id.getText().isEmpty() || this.tx_nombre.getText().isEmpty() || this.tx_apellido.getText().isEmpty()
                || this.tx_telefono.getText().isEmpty() || this.tx_email.getText().isEmpty()) {
            lbvalidacion.setText("Por favor, complete todos los campos.");
            return;
        }

        if (!this.tx_nombre.getText().matches("[a-zA-Z ]+")) {
            lbvalidacion.setText("El campo Nombre solo debe contener letras.");
            return;
        }

        if (!this.tx_apellido.getText().matches("[a-zA-Z ]+")) {
            lbvalidacion.setText("El campo Apellido solo debe contener letras.");
            return;
        }

        if (!this.tx_telefono.getText().matches("\\d+")) {
            lbvalidacion.setText("El campo Teléfono solo debe contener números.");
            return;
        }

        if (!this.tx_email.getText().matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
            lbvalidacion.setText("El campo Email no es válido.");
            return;
        }

        lbvalidacion.setText(""); // Limpiar cualquier mensaje de validación anterior

        try {
            int idProveedor = Integer.parseInt(this.tx_id.getText());
            objProv.setId_proveedor(idProveedor);  // Asignar el ID como un entero
        } catch (NumberFormatException e) {
            lbvalidacion.setText("El campo ID debe ser un número entero.");
            return;
        }
        
        objProv.setNombre_proveedor(this.tx_nombre.getText());
        objProv.setApellido_proveedor(this.tx_apellido.getText());
        objProv.setTelefono(this.tx_telefono.getText());
        objProv.setEmail(this.tx_email.getText());

        // Llamar al método para grabar el proveedor
        JOptionPane.showMessageDialog(null, objProv.GrabarProveedor());

        // Limpiar los campos y actualizar la lista de proveedores
        LimpiarCajasTextoProveedor();
        ListarProveedores();
    }//GEN-LAST:event_bt_grabarActionPerformed

    private void bt_modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_modificarActionPerformed

        int rec = this.jTable1.getSelectedRow();
        if (rec == -1) {
            JOptionPane.showMessageDialog(null, "Por favor, seleccione un proveedor para modificar.");
            return;
        }

        // Validaciones
        if (this.tx_nombre.getText().isEmpty() || this.tx_apellido.getText().isEmpty()
                || this.tx_telefono.getText().isEmpty() || this.tx_email.getText().isEmpty()) {
            lbvalidacion.setText("Por favor, complete todos los campos.");
            return;
        }

        if (!this.tx_nombre.getText().matches("[a-zA-Z ]+")) {
            lbvalidacion.setText("El campo Nombre solo debe contener letras.");
            return;
        }

        if (!this.tx_apellido.getText().matches("[a-zA-Z ]+")) {
            lbvalidacion.setText("El campo Apellido solo debe contener letras.");
            return;
        }

        if (!this.tx_telefono.getText().matches("\\d+")) {
            lbvalidacion.setText("El campo Teléfono solo debe contener números.");
            return;
        }

        if (!this.tx_email.getText().matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
            lbvalidacion.setText("El campo Email no es válido.");
            return;
        }

        lbvalidacion.setText(""); // Limpiar cualquier mensaje de validación anterior

        DataProveedores objprov = new DataProveedores();
        objprov.setId_proveedor(Integer.parseInt(this.tx_id.getText()));  // Obtener ID del campo TX_ID
        objprov.setNombre_proveedor(this.tx_nombre.getText());
        objprov.setApellido_proveedor(this.tx_apellido.getText());
        objprov.setTelefono(this.tx_telefono.getText());
        objprov.setEmail(this.tx_email.getText());

        // Ejecutar el método de actualización en la base de datos
        JOptionPane.showMessageDialog(null, objprov.EditarProveedor());

        LimpiarCajasTextoProveedor();
        ListarProveedores(); // Recargar la lista de p/ Recargar la lista de proveedores en la tabla

    }//GEN-LAST:event_bt_modificarActionPerformed

    private void bt_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_eliminarActionPerformed
        int rec = this.jTable1.getSelectedRow();
        if (rec == -1) {
            JOptionPane.showMessageDialog(null, "Por favor, seleccione un proveedor para eliminar.");
            return;
        }

        // Confirmación de eliminación
        int Res = JOptionPane.showConfirmDialog(null, "¿Está seguro de eliminar al proveedor: " + this.tx_nombre.getText() + "?");
        if (Res == JOptionPane.YES_OPTION) {
            DataProveedores objProv = new DataProveedores();
            objProv.setId_proveedor(Integer.parseInt(this.tx_id.getText()));  // Usar el ID de TX_ID para eliminar
            JOptionPane.showMessageDialog(null, objProv.EliminarProveedor());

            LimpiarCajasTextoProveedor(); // Limpiar campos de texto
            ListarProveedores(); // Actualizar la tabla
            JOptionPane.showMessageDialog(null, "Proveedor eliminado con éxito.");
        }

    }//GEN-LAST:event_bt_eliminarActionPerformed

    private void jTable1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MousePressed
        int rec = this.jTable1.getSelectedRow();
        this.tx_id.setText(jTable1.getValueAt(rec, 0).toString());
        this.tx_nombre.setText(jTable1.getValueAt(rec, 1).toString());
        this.tx_apellido.setText(jTable1.getValueAt(rec, 2).toString());
        this.tx_telefono.setText(jTable1.getValueAt(rec, 3).toString());
        this.tx_email.setText(jTable1.getValueAt(rec, 4).toString());
    }//GEN-LAST:event_jTable1MousePressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_eliminar;
    private javax.swing.JButton bt_grabar;
    private javax.swing.JButton bt_modificar;
    private javax.swing.JButton bt_nuevo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lbvalidacion;
    private javax.swing.JTextField tx_apellido;
    private javax.swing.JTextField tx_email;
    private javax.swing.JTextField tx_id;
    private javax.swing.JTextField tx_nombre;
    private javax.swing.JTextField tx_telefono;
    // End of variables declaration//GEN-END:variables
}
