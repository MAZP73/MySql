package Capa_Presentacion;

import Capa_Datos.Conexion;
import Capa_Negocio.DataCategorias;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class Categorias extends javax.swing.JInternalFrame {

    /**
     * Creates new form Categorias
     */
    public Categorias() {
        initComponents();
        ListarCategorias();

    }

    public void ListarCategorias() {
        DefaultTableModel tabla = new DefaultTableModel();
        DataCategorias objCat = new DataCategorias();
        ArrayList<DataCategorias> listaCategorias = objCat.listarCategorias();

        // Añadiendo las columnas
        tabla.addColumn("ID Categoría");
        tabla.addColumn("Nombre Categoría");

        // Configurar el número de filas en la tabla según el tamaño de la lista
        tabla.setRowCount(listaCategorias.size());

        int i = 0;
        for (DataCategorias categoria : listaCategorias) {
            tabla.setValueAt(categoria.getId_categoria(), i, 0);
            tabla.setValueAt(categoria.getNombre_categoria(), i, 1);
            i++;
        }

        this.jTable1.setModel(tabla);  // Establecer el modelo de la tabla en el jTable
    }

    public void LimpiarCajasTexto() {
        this.tx_nombre_categoria.setText("");  // Limpiar el campo de código
        this.tx_selectdescripcion.setText("");  // Limpiar el campo de nombre
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        tx_nombre_categoria = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        bt_Guardar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        bt_actualizar = new javax.swing.JButton();
        bt_eliminar = new javax.swing.JButton();
        tx_selectdescripcion = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        lbvalidacion = new javax.swing.JLabel();

        setClosable(true);
        setVisible(true);

        jLabel1.setText("Nueva Categoria");

        jLabel2.setText("Descripcion:");

        bt_Guardar.setText("Guardar");
        bt_Guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_GuardarActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        bt_actualizar.setText("Actualizar");
        bt_actualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_actualizarActionPerformed(evt);
            }
        });

        bt_eliminar.setText("Eliminar");
        bt_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bt_eliminarActionPerformed(evt);
            }
        });

        jLabel3.setText("Descripcion:");

        lbvalidacion.setText(".");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 492, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tx_nombre_categoria, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(27, 27, 27)
                                .addComponent(bt_Guardar, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(bt_actualizar)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lbvalidacion))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(tx_selectdescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(bt_eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(30, 30, 30))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tx_nombre_categoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(bt_Guardar, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tx_selectdescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bt_actualizar)
                    .addComponent(bt_eliminar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbvalidacion)
                .addContainerGap(55, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bt_GuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_GuardarActionPerformed
        if (this.tx_nombre_categoria.getText().isEmpty()) {
            lbvalidacion.setText("Por favor, ingrese el nombre de la categoría.");
            return;
        }

        DataCategorias objCategoria = new DataCategorias();
        objCategoria.setNombre_categoria(this.tx_nombre_categoria.getText());

        // Guardar la nueva categoría
        String resultado = objCategoria.agregarCategoria();
        JOptionPane.showMessageDialog(null, resultado);

        LimpiarCajasTexto();  // Limpiar los campos de texto
        ListarCategorias();   // Actualizar la lista de categorías en la tabla
    }//GEN-LAST:event_bt_GuardarActionPerformed

    private void bt_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_eliminarActionPerformed

        int rec = this.jTable1.getSelectedRow();  // Obtenemos la fila seleccionada
        if (rec == -1) {
            JOptionPane.showMessageDialog(null, "Por favor, seleccione una categoría para eliminar.");
            return;
        }

        // Obtener ID de la categoría seleccionada
        int idCategoria = (int) this.jTable1.getValueAt(rec, 0);  // Asumimos que el ID está en la primera columna

        DataCategorias objCategoria = new DataCategorias();
        objCategoria.setId_categoria(idCategoria);

        // Eliminar la categoría
        String resultado = objCategoria.eliminarCategoria();
        JOptionPane.showMessageDialog(null, resultado);

        ListarCategorias();   // Actualizar la lista de categorías
    }//GEN-LAST:event_bt_eliminarActionPerformed

    private void bt_actualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bt_actualizarActionPerformed

        int rec = this.jTable1.getSelectedRow();  // Obtenemos la fila seleccionada
        if (rec == -1) {
            JOptionPane.showMessageDialog(null, "Por favor, seleccione una categoría para actualizar.");
            return;
        }

        // Obtener los datos de la fila seleccionada
        int idCategoria = (int) this.jTable1.getValueAt(rec, 0);  // Asumimos que el ID está en la primera columna
        String nombreCategoria = (String) this.jTable1.getValueAt(rec, 1);  // El nombre está en la segunda columna

        // Establecer los valores en los campos de texto para ser editados
        this.tx_nombre_categoria.setText(nombreCategoria);

        // Actualizar los datos de la categoría
        DataCategorias objCategoria = new DataCategorias();
        objCategoria.setId_categoria(idCategoria);
        objCategoria.setNombre_categoria(this.tx_selectdescripcion.getText());

        // Ejecutar la actualización
        String resultado = objCategoria.modificarCategoria();
        JOptionPane.showMessageDialog(null, resultado);

        LimpiarCajasTexto();  // Limpiar los campos de texto
        ListarCategorias();   // Actualizar la lista de categorías
    }//GEN-LAST:event_bt_actualizarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bt_Guardar;
    private javax.swing.JButton bt_actualizar;
    private javax.swing.JButton bt_eliminar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lbvalidacion;
    private javax.swing.JTextField tx_nombre_categoria;
    private javax.swing.JTextField tx_selectdescripcion;
    // End of variables declaration//GEN-END:variables
}
